### Start of the race ###
WaitForGo()
Speed(100)

### Racing until terminated ###
while Globals.running:
	# Drive in the center until turn 2
	AimForLane(0)
	
	WaitForWaypoint(2)
    
	
### End of the race ###
FinishRace()
