#!/bin/bash
gksudo ./DisplayReadings.py
